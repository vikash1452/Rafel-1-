package com.example.live

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.voice.AudioPlaybackManager
import com.example.voice.RafelVoiceState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class LiveAudioPipelineTraceTest {

    private lateinit var context: Context
    private lateinit var playbackManager: AudioPlaybackManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun testCompleteVoiceTurnTraceSequence() = runBlocking {
        val playbackStartedCalled = AtomicBoolean(false)
        val playbackFinishedCalled = AtomicBoolean(false)
        val chunksWritten = AtomicInteger(0)

        playbackManager = AudioPlaybackManager(
            context = context,
            onPlaybackStarted = { playbackStartedCalled.set(true) },
            onPlaybackFinished = { playbackFinishedCalled.set(true) },
            onAudioPlayed = { chunksWritten.incrementAndGet() }
        )

        // Simulate complete real pipeline sequence:
        // 1. User turn sent
        val genId = 1001L
        playbackManager.prepareForPlayback()

        // 2. Gemini sends response audio chunks (24kHz 16-bit PCM Mono)
        val chunk1 = ByteArray(1920) { 1 } // 40ms audio
        val chunk2 = ByteArray(1920) { 2 } // 40ms audio
        val chunk3 = ByteArray(1920) { 3 } // 40ms audio

        playbackManager.enqueueChunk(genId, chunk1)
        playbackManager.enqueueChunk(genId, chunk2)
        playbackManager.enqueueChunk(genId, chunk3)

        // Wait brief moment for playback loop to process
        var started = false
        for (i in 0 until 15) {
            if (playbackStartedCalled.get()) {
                started = true
                break
            }
            kotlinx.coroutines.delay(20)
        }

        // 3. Server turn completed
        playbackManager.markTurnComplete(genId)
        kotlinx.coroutines.delay(100)

        // Assert that playback started immediately on chunk 1
        assertTrue("Playback MUST start immediately on first audio chunk", started)
        assertTrue("Audio chunks must be processed by AudioTrack", chunksWritten.get() > 0)

        playbackManager.release()
    }

    @Test
    fun testSpeakerDiagnosticTest1AndTest2() = runBlocking {
        val diagManager = com.example.voice.AudioDiagnosisManager(context)

        // Test 1: 24 kHz, 16-bit, mono PCM test tone through AudioPlaybackManager
        val test1Result = diagManager.runTest1LocalPlayback()
        assertTrue("Test 1 (TEST SPEAKER) must succeed", test1Result.isSuccess)
        assertEquals(48000, test1Result.decodedPcmBytes) // 1000ms * 24000 * 2 = 48,000 bytes
        assertTrue("AudioTrack state must be initialized", test1Result.audioTrackState.contains("INITIALIZED"))
        assertTrue("AudioTrack playState must be playing", test1Result.audioTrackPlayState.contains("PLAYING"))
        assertEquals("SPEAKER TEST PLAYED", test1Result.writeResult)

        // Test 2: Gemini Live 24 kHz PCM response payload through the same path
        val test4Result = diagManager.runTest4GeminiPcmToAudioTrack()
        assertTrue("Test 2 (Gemini Live PCM Playback) must succeed", test4Result.isSuccess)
        assertEquals(33600, test4Result.decodedPcmBytes) // 700ms * 24000 * 2 = 33,600 bytes
        assertTrue("Gemini PCM writeResult must confirm bytes written", test4Result.writeResult.contains("Enqueued and streamed"))
    }

    @Test
    fun testSessionIdIncrementAndIsolation() {
        val prefs = context.getSharedPreferences("rafel_settings", Context.MODE_PRIVATE)
        prefs.edit().putString("gemini_api_key", "test_mock_api_key_12345").commit()

        val toolEngine = com.example.tools.ToolExecutionEngine(context)
        val sessionManager = LiveSessionManager(
            context = context,
            toolEngine = toolEngine,
            onAudioOut = { _, _ -> },
            onTurnComplete = {},
            onStateChange = {},
            onServerInterrupted = {}
        )

        val id1 = sessionManager.currentSessionId.get()
        sessionManager.startSession()
        val id2 = sessionManager.currentSessionId.get()
        assertTrue("Starting session must increment session ID", id2 > id1)

        sessionManager.stopSession()
        assertFalse("Stopped session must not be connected", sessionManager.isConnected())
    }
}
