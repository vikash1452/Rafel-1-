package com.example.voice

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ProactiveConversationManagerTest {

    private lateinit var context: Context
    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)
    private val triggeredPrompt = AtomicReference<String?>(null)
    private lateinit var proactiveManager: ProactiveConversationManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        triggeredPrompt.set(null)
        proactiveManager = ProactiveConversationManager(
            context = context,
            scope = testScope,
            onTriggerProactiveTurn = { prompt ->
                triggeredPrompt.set(prompt)
            }
        )
        proactiveManager.isEnabled = true
        proactiveManager.resetCycle()
    }

    @Test
    fun testProactiveScheduled_afterAssistantSpeechFinished() = testScope.runTest {
        proactiveManager.onAssistantSpeechFinished(
            isAiSpeaking = false,
            isSessionConnected = true,
            isMicMuted = false
        )

        assertTrue("Proactive speech must be scheduled after assistant speech finishes", proactiveManager.isScheduled())

        // Advance time past silence threshold (4000ms)
        advanceTimeBy(4500L)

        assertNotNull("Proactive prompt must be triggered after 4s silence", triggeredPrompt.get())
        assertTrue("Proactive prompt must guide follow-up", triggeredPrompt.get()?.contains("Proactive conversation prompt") == true)
    }

    @Test
    fun testProactiveCancelled_whenUserStartsSpeaking() = testScope.runTest {
        proactiveManager.onAssistantSpeechFinished(
            isAiSpeaking = false,
            isSessionConnected = true,
            isMicMuted = false
        )
        assertTrue("Proactive speech should be scheduled", proactiveManager.isScheduled())

        // User speaks after 2 seconds
        advanceTimeBy(2000L)
        proactiveManager.onUserSpeechStarted()

        assertFalse("Proactive speech must be cancelled immediately when user starts speaking", proactiveManager.isScheduled())

        advanceTimeBy(3000L)
        assertNull("Prompt must not have fired because user spoke", triggeredPrompt.get())
    }

    @Test
    fun testProactiveCancelled_onSilenceCommand() = testScope.runTest {
        proactiveManager.onAssistantSpeechFinished(
            isAiSpeaking = false,
            isSessionConnected = true,
            isMicMuted = false
        )

        // User says "Rafel chup ho jao"
        proactiveManager.onUserTranscriptReceived("Rafel chup ho jao")

        assertTrue("Proactive conversation must be paused by user silence command", proactiveManager.isPausedByUser)
        assertFalse("Scheduled job must be cancelled on silence command", proactiveManager.isScheduled())
    }

    @Test
    fun testProactiveResumed_whenUserSpeaksNewQuery() = testScope.runTest {
        // First pause by user command
        proactiveManager.onUserTranscriptReceived("chup raho")
        assertTrue(proactiveManager.isPausedByUser)

        // User asks a new question
        proactiveManager.onUserTranscriptReceived("India ki capital kya hai")
        assertFalse("Proactive mode must unpause when user asks a new question", proactiveManager.isPausedByUser)
    }

    @Test
    fun testProactiveQuietCooldown_preventsRunawayMonologue() = testScope.runTest {
        // Trigger one proactive cycle
        proactiveManager.onAssistantSpeechFinished(false, true, false)
        advanceTimeBy(4500L)
        assertNotNull(triggeredPrompt.get())

        // Reset trigger capture
        triggeredPrompt.set(null)

        // Assistant finished speaking the proactive follow-up, but user is still silent
        proactiveManager.onAssistantSpeechFinished(false, true, false)

        assertFalse("Quiet cooldown must prevent scheduling another immediate proactive turn", proactiveManager.isScheduled())
        advanceTimeBy(5000L)
        assertNull("No duplicate proactive prompt should fire during cooldown", triggeredPrompt.get())
    }
}
