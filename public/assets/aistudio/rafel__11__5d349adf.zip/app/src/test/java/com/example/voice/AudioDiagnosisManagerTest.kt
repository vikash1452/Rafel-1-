package com.example.voice

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AudioDiagnosisManagerTest {

    private lateinit var context: Context
    private lateinit var diagnosisManager: AudioDiagnosisManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        diagnosisManager = AudioDiagnosisManager(context)
    }

    @Test
    fun testToneGeneration() {
        val tone = diagnosisManager.generateTestPcmTone(durationMs = 100, freqHz = 440.0)
        // 24000 samples/sec * 0.1 sec = 2400 samples * 2 bytes/sample = 4800 bytes
        assertEquals(4800, tone.size)
        assertTrue(tone.any { it != 0.toByte() })
    }

    @Test
    fun testStage1LocalPlayback() = runBlocking {
        val result = diagnosisManager.runTest1LocalPlayback()
        assertEquals("1. Local AudioTrack Playback (24kHz Sine Tone)", result.testName)
        assertTrue(result.isSuccess)
        assertTrue(result.receivedBytes > 0)
        assertTrue(result.decodedPcmBytes > 0)
        assertNull(result.errorMessage)
    }

    @Test
    fun testStage2GeminiReception() = runBlocking {
        val result = diagnosisManager.runTest2GeminiReception()
        assertTrue(result.isSuccess)
        assertTrue(result.receivedBytes > 0)
        assertNull(result.errorMessage)
    }

    @Test
    fun testStage3GeminiDecoding() = runBlocking {
        val result = diagnosisManager.runTest3GeminiDecoding()
        assertTrue(result.isSuccess)
        assertTrue(result.decodedPcmBytes > 0)
        assertEquals(0, result.decodedPcmBytes % 2) // 16-bit alignment check
    }

    @Test
    fun testStage4GeminiPcmToAudioTrack() = runBlocking {
        val result = diagnosisManager.runTest4GeminiPcmToAudioTrack()
        assertTrue(result.isSuccess)
        assertTrue(result.receivedBytes > 0)
        assertTrue(result.decodedPcmBytes > 0)
        assertNull(result.errorMessage)
    }
}
