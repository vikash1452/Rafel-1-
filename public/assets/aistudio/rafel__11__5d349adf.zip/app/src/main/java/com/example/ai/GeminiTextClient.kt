package com.example.ai

import com.example.conversation.UnifiedMessage
import com.example.voice.RafelLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Direct Gemini REST client for typed text chat responses.
 * Uses gemini-3.5-flash with fallback to gemini-2.5-flash, maintaining
 * the exact same Rafel feminine persona and shared conversation memory.
 */
class GeminiTextClient(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val mediaTypeJson = "application/json; charset=utf-8".toMediaType()

    suspend fun generateResponse(
        apiKey: String,
        recentHistory: List<UnifiedMessage>,
        newPrompt: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Gemini API key is missing. Please set it in Settings."))
        }

        // Build contents array with conversation history
        val contentsArray = buildJsonArray {
            recentHistory.takeLast(16).forEach { msg ->
                if (msg.text.isNotBlank()) {
                    add(buildJsonObject {
                        put("role", if (msg.isUser) "user" else "model")
                        putJsonArray("parts") {
                            add(buildJsonObject { put("text", msg.text) })
                        }
                    })
                }
            }
            // Append current prompt
            add(buildJsonObject {
                put("role", "user")
                putJsonArray("parts") {
                    add(buildJsonObject { put("text", newPrompt) })
                }
            })
        }

        val requestBodyJson = buildJsonObject {
            putJsonObject("system_instruction") {
                putJsonArray("parts") {
                    add(buildJsonObject { put("text", RafelPersona.SYSTEM_PROMPT) })
                }
            }
            put("contents", contentsArray)
            putJsonObject("generationConfig") {
                put("temperature", 0.75)
                put("topP", 0.95)
                put("maxOutputTokens", 1000)
            }
        }.toString()

        val primaryModel = "gemini-3.5-flash"
        val fallbackModel = "gemini-2.5-flash"

        val firstResult = executeGenerate(primaryModel, apiKey, requestBodyJson)
        if (firstResult.isSuccess) {
            return@withContext firstResult
        }

        RafelLogger.logDiagnostic("Primary model $primaryModel error (${firstResult.exceptionOrNull()?.message}). Trying fallback $fallbackModel...")
        executeGenerate(fallbackModel, apiKey, requestBodyJson)
    }

    private fun executeGenerate(
        modelName: String,
        apiKey: String,
        jsonBody: String
    ): Result<String> {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toRequestBody(mediaTypeJson))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return Result.failure(
                        Exception("Gemini HTTP ${response.code}: $responseStr")
                    )
                }

                val jsonResponse = json.parseToJsonElement(responseStr).jsonObject
                val text = jsonResponse["candidates"]
                    ?.jsonArray?.firstOrNull()
                    ?.jsonObject?.get("content")
                    ?.jsonObject?.get("parts")
                    ?.jsonArray?.firstOrNull()
                    ?.jsonObject?.get("text")
                    ?.jsonPrimitive?.content

                if (!text.isNullOrBlank()) {
                    Result.success(text.trim())
                } else {
                    Result.failure(Exception("Empty candidate returned from Gemini"))
                }
            }
        } catch (e: Exception) {
            RafelLogger.logError("Failed to generate Gemini text response", e)
            Result.failure(e)
        }
    }
}
