package com.example.voice

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class ProactiveConversationManager(
    private val context: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main),
    private val onTriggerProactiveTurn: (prompt: String) -> Unit
) {
    companion object {
        const val TAG = "RAFEL-DIAGNOSTIC"
        const val DEFAULT_PROACTIVE_DELAY_MS = 4000L // 4 seconds of silence (3-5s range)
        private const val PREFS_NAME = "rafel_proactive_prefs"
        private const val KEY_PROACTIVE_ENABLED = "proactive_enabled"

        val SILENCE_COMMANDS = listOf(
            "chup", "chup ho jao", "chup raho", "stop", "shant", "shant raho",
            "so jao", "ruk jao", "don't speak", "dont speak", "quiet", "be quiet"
        )
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isEnabled: Boolean
        get() = prefs.getBoolean(KEY_PROACTIVE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_PROACTIVE_ENABLED, value).apply()

    @Volatile
    var isPausedByUser: Boolean = false
        private set

    @Volatile
    var hasSpokenProactivelyThisCycle: Boolean = false
        internal set

    private var scheduledJob: Job? = null

    fun isScheduled(): Boolean = scheduledJob?.isActive == true

    /**
     * Inspects user utterance. If user commanded silence, pauses proactive mode.
     * If user asked a regular question, automatically unpauses proactive mode.
     */
    fun onUserTranscriptReceived(transcript: String) {
        val clean = transcript.trim().lowercase(Locale.ROOT)
        val isSilenceCommand = SILENCE_COMMANDS.any { clean == it || clean.contains(" $it") || clean.startsWith("$it ") }

        if (isSilenceCommand) {
            pauseByUser("User commanded silence: '$transcript'")
        } else {
            if (isPausedByUser) {
                resumeFromPause()
            }
        }
    }

    /**
     * Called when Rafel finishes speaking an utterance.
     * Starts the 3-5s silence countdown if proactive mode is active and eligible.
     */
    fun onAssistantSpeechFinished(isAiSpeaking: Boolean, isSessionConnected: Boolean, isMicMuted: Boolean) {
        cancelScheduledPrompt("Restarting silence window after assistant finished speaking")

        if (!isEnabled) {
            Log.i(TAG, "PROACTIVE_SPEECH_CANCELLED: reason='Proactive conversation is disabled'")
            return
        }

        if (isPausedByUser) {
            Log.i(TAG, "PROACTIVE_SPEECH_CANCELLED: reason='Proactive conversation is paused by user command'")
            return
        }

        if (hasSpokenProactivelyThisCycle) {
            Log.i(TAG, "PROACTIVE_SPEECH_CANCELLED: reason='Quiet cooldown in effect to prevent endless monologue'")
            return
        }

        if (!isSessionConnected || isMicMuted || isAiSpeaking) {
            Log.i(TAG, "PROACTIVE_SPEECH_CANCELLED: reason='Session not in listening state'")
            return
        }

        Log.i(TAG, "PROACTIVE_SPEECH_SCHEDULED: delayMs=$DEFAULT_PROACTIVE_DELAY_MS")

        scheduledJob = scope.launch {
            delay(DEFAULT_PROACTIVE_DELAY_MS)

            if (!isEnabled || isPausedByUser || hasSpokenProactivelyThisCycle) {
                return@launch
            }

            hasSpokenProactivelyThisCycle = true

            val proactiveNudge = "[Proactive conversation prompt: The user has been quiet for 4 seconds. Naturally continue the active topic or share an interesting, relevant observation or follow-up question in your warm Hindi/Hinglish persona. Do not repeat greetings, do not repeat what you just said, and do not say 'how may I help you'. Keep it brief (1-2 sentences).]"
            Log.i(TAG, "PROACTIVE_SPEECH_TRIGGERED: delayMs=$DEFAULT_PROACTIVE_DELAY_MS")
            onTriggerProactiveTurn(proactiveNudge)
        }
    }

    /**
     * Called the moment user starts speaking (or barge-in occurs).
     * Immediately cancels any scheduled proactive countdown.
     */
    fun onUserSpeechStarted() {
        hasSpokenProactivelyThisCycle = false
        cancelScheduledPrompt("User started speaking")
    }

    fun pauseByUser(reason: String) {
        isPausedByUser = true
        cancelScheduledPrompt(reason)
        Log.i(TAG, "PROACTIVE_SPEECH_CANCELLED: reason='$reason'")
    }

    fun resumeFromPause() {
        isPausedByUser = false
        Log.i(TAG, "Proactive conversation unpaused after user spoke new query.")
    }

    fun cancelScheduledPrompt(reason: String) {
        if (scheduledJob?.isActive == true) {
            scheduledJob?.cancel()
            Log.i(TAG, "PROACTIVE_SPEECH_CANCELLED: reason='$reason'")
        }
        scheduledJob = null
    }

    fun resetCycle() {
        hasSpokenProactivelyThisCycle = false
        cancelScheduledPrompt("Cycle reset")
    }
}
