package com.example.conversation

import android.content.Context
import com.example.ai.GeminiTextClient
import com.example.memory.ConversationTurnEntity
import com.example.memory.RafelMemoryDatabase
import com.example.tools.AssistantIntent
import com.example.tools.AssistantIntentRouter
import com.example.tools.SemanticIntentResult
import com.example.tools.ToolExecutionEngine
import com.example.tools.ToolSafetyGate
import com.example.tools.UserTurnContext
import com.example.voice.RafelLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

/**
 * Authoritative Central Conversation Manager for Rafel.
 *
 * UNIFIES Voice and Chat conversations into a SINGLE underlying conversation stream:
 * - Spoken turns (MIC -> STT -> Gemini Live audio) appear in the chat timeline with "Voice" badge.
 * - Typed turns (Chat -> Text -> Gemini) appear in the chat timeline with "Text" badge.
 * - Both share the same Room database persistence, intent routing, and memory context.
 * - Gemini Live is injected with recent typed messages so voice continuity is preserved.
 * - Gemini Text is injected with recent voice messages so chat continuity is preserved.
 */
class RafelConversationManager private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val db = RafelMemoryDatabase.getInstance(appContext)
    private val memoryDao = db.memoryDao()
    private val geminiTextClient = GeminiTextClient()

    private val _messages = MutableStateFlow<List<UnifiedMessage>>(emptyList())
    val messages: StateFlow<List<UnifiedMessage>> = _messages.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    init {
        loadHistoryFromDatabase()
    }

    private fun loadHistoryFromDatabase() {
        scope.launch {
            try {
                val entities = memoryDao.getRecentTurns(limit = 40)
                val loaded = entities.reversed().map { entity ->
                    val type = when (entity.messageType) {
                        "USER_VOICE" -> UnifiedMessageType.USER_VOICE
                        "RAFEL_VOICE" -> UnifiedMessageType.RAFEL_VOICE
                        "USER_TEXT" -> UnifiedMessageType.USER_TEXT
                        "RAFEL_TEXT" -> UnifiedMessageType.RAFEL_TEXT
                        else -> if (entity.role == "user") UnifiedMessageType.USER_TEXT else UnifiedMessageType.RAFEL_TEXT
                    }
                    UnifiedMessage(
                        id = "db_${entity.id}",
                        type = type,
                        text = entity.text,
                        timestamp = entity.timestamp
                    )
                }
                if (loaded.isNotEmpty()) {
                    _messages.value = loaded
                    RafelLogger.logVoice("Loaded ${loaded.size} unified conversation turns from memory.")
                }
            } catch (e: Exception) {
                RafelLogger.logError("Failed to load conversation history from database", e)
            }
        }
    }

    fun addUserVoiceMessage(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return

        // Deduplicate rapid consecutive identical voice transcripts
        val current = _messages.value
        val last = current.lastOrNull()
        if (last != null && last.type == UnifiedMessageType.USER_VOICE && last.text.equals(clean, ignoreCase = true)) {
            return
        }

        val msg = UnifiedMessage(
            id = UUID.randomUUID().toString(),
            type = UnifiedMessageType.USER_VOICE,
            text = clean,
            timestamp = System.currentTimeMillis()
        )
        appendMessage(msg)
        persistTurn("user", clean, "USER_VOICE", msg.timestamp)
    }

    fun addRafelVoiceMessage(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return

        val msg = UnifiedMessage(
            id = UUID.randomUUID().toString(),
            type = UnifiedMessageType.RAFEL_VOICE,
            text = clean,
            timestamp = System.currentTimeMillis()
        )
        appendMessage(msg)
        persistTurn("assistant", clean, "RAFEL_VOICE", msg.timestamp)
    }

    fun appendRafelVoiceChunk(chunk: String) {
        val current = _messages.value
        val last = current.lastOrNull()
        if (last != null && last.type == UnifiedMessageType.RAFEL_VOICE) {
            val updated = current.toMutableList()
            val newText = last.text + chunk
            updated[updated.lastIndex] = last.copy(text = newText)
            _messages.value = updated
        } else {
            addRafelVoiceMessage(chunk)
        }
    }

    fun addUserTextMessage(text: String): UnifiedMessage {
        val clean = text.trim()
        val msg = UnifiedMessage(
            id = UUID.randomUUID().toString(),
            type = UnifiedMessageType.USER_TEXT,
            text = clean,
            timestamp = System.currentTimeMillis()
        )
        appendMessage(msg)
        persistTurn("user", clean, "USER_TEXT", msg.timestamp)
        return msg
    }

    fun addRafelTextMessage(text: String): UnifiedMessage {
        val clean = text.trim()
        val msg = UnifiedMessage(
            id = UUID.randomUUID().toString(),
            type = UnifiedMessageType.RAFEL_TEXT,
            text = clean,
            timestamp = System.currentTimeMillis()
        )
        appendMessage(msg)
        persistTurn("assistant", clean, "RAFEL_TEXT", msg.timestamp)
        return msg
    }

    /**
     * Complete lifecycle processor for a typed user chat message.
     * Evaluates intents, executes tools through the authoritative ToolSafetyGate,
     * or queries Gemini with full shared conversation context.
     */
    fun processUserTextMessage(
        text: String,
        apiKey: String,
        toolEngine: ToolExecutionEngine?
    ) {
        val clean = text.trim()
        if (clean.isBlank()) return

        addUserTextMessage(clean)
        _isThinking.value = true

        scope.launch {
            try {
                // 1. Identify intent
                val intentResult = AssistantIntentRouter.classifyIntent(clean)
                RafelLogger.logGeminiResponse("Chat typed intent classified: ${intentResult.intent} (explicitAction=${intentResult.explicitAction})")

                // 2. If it's a device/phone tool action
                if (toolEngine != null && isActionIntent(intentResult.intent)) {
                    val handled = handleChatToolAction(clean, intentResult, toolEngine)
                    if (handled) {
                        _isThinking.value = false
                        return@launch
                    }
                }

                // 3. Normal conversation query: Call Gemini Text Generation with full context
                val history = _messages.value.dropLast(1) // exclude the just-added message
                val responseResult = geminiTextClient.generateResponse(
                    apiKey = apiKey,
                    recentHistory = history,
                    newPrompt = clean
                )

                if (responseResult.isSuccess) {
                    val reply = responseResult.getOrNull().orEmpty()
                    addRafelTextMessage(reply)
                } else {
                    val err = responseResult.exceptionOrNull()?.message ?: "Error connecting to Gemini"
                    val userFriendly = when {
                        err.contains("API key", ignoreCase = true) -> "API key missing hai. Settings mein enter karo please."
                        err.contains("quota", ignoreCase = true) || err.contains("429") -> "Gemini API quota exhaust ho gaya hai."
                        else -> "Network issue aa raha hai yaar, ek baar connection check karo."
                    }
                    addRafelTextMessage(userFriendly)
                }
            } catch (e: Exception) {
                RafelLogger.logError("Error processing chat text message", e)
                addRafelTextMessage("Kuch gadbad hui, thodi der baad try karo.")
            } finally {
                _isThinking.value = false
            }
        }
    }

    private suspend fun handleChatToolAction(
        transcript: String,
        intentResult: SemanticIntentResult,
        toolEngine: ToolExecutionEngine
    ): Boolean {
        val (toolName, toolArgs) = mapIntentToTool(intentResult) ?: return false

        val turnContext = UserTurnContext(
            userTurnId = "text_${System.currentTimeMillis()}",
            transcript = transcript,
            toolCallId = "call_text_${System.currentTimeMillis()}"
        )

        val safetyDecision = ToolSafetyGate.evaluate(
            toolName = toolName,
            args = toolArgs,
            turnContext = turnContext
        )

        return if (safetyDecision.allowed) {
            val execResult = toolEngine.execute(toolName, toolArgs, turnContext)
            val friendlyResponse = formatToolConfirmation(intentResult.intent, intentResult.target, execResult)
            addRafelTextMessage(friendlyResponse)
            true
        } else {
            val reason = if (safetyDecision.reason.isNotBlank()) {
                safetyDecision.reason
            } else {
                "Iski security permission required hai."
            }
            addRafelTextMessage(reason)
            true
        }
    }

    private fun isActionIntent(intent: AssistantIntent): Boolean {
        return when (intent) {
            AssistantIntent.OPEN_APP,
            AssistantIntent.CALL_CONTACT,
            AssistantIntent.SEND_WHATSAPP,
            AssistantIntent.SEND_SMS,
            AssistantIntent.SEND_EMAIL,
            AssistantIntent.SEARCH_YOUTUBE,
            AssistantIntent.DEVICE_CONTROL -> true
            else -> false
        }
    }

    private fun mapIntentToTool(intentResult: SemanticIntentResult): Pair<String, JsonObject>? {
        return when (intentResult.intent) {
            AssistantIntent.OPEN_APP -> {
                val targetApp = intentResult.target ?: "Settings"
                Pair("openApp", buildJsonObject { put("packageName", targetApp) })
            }
            AssistantIntent.CALL_CONTACT -> {
                val contact = intentResult.target ?: return null
                Pair("searchAndCallContact", buildJsonObject {
                    put("contactName", contact)
                    put("useDialer", false)
                })
            }
            AssistantIntent.SEND_WHATSAPP -> {
                val contact = intentResult.target ?: return null
                val msg = intentResult.secondaryData ?: ""
                Pair("sendWhatsAppMessage", buildJsonObject {
                    put("contactName", contact)
                    put("message", msg)
                })
            }
            AssistantIntent.SEND_SMS -> {
                val contact = intentResult.target ?: return null
                val msg = intentResult.secondaryData ?: ""
                Pair("sendSms", buildJsonObject {
                    put("contactName", contact)
                    put("message", msg)
                    put("confirmed", false)
                })
            }
            AssistantIntent.SEND_EMAIL -> {
                val recipient = intentResult.target ?: return null
                val body = intentResult.secondaryData ?: ""
                Pair("sendGmail", buildJsonObject {
                    put("recipientEmail", recipient)
                    put("subject", "Message from Rafel")
                    put("body", body)
                })
            }
            AssistantIntent.SEARCH_YOUTUBE -> {
                val query = intentResult.target ?: return null
                Pair("searchYouTube", buildJsonObject { put("query", query) })
            }
            else -> null
        }
    }

    private fun formatToolConfirmation(intent: AssistantIntent, target: String?, execResult: String): String {
        return when (intent) {
            AssistantIntent.OPEN_APP -> "Okay, ${target ?: "app"} open kar rahi hoon."
            AssistantIntent.CALL_CONTACT -> "${target ?: "Contact"} ko call mila rahi hoon."
            AssistantIntent.SEND_WHATSAPP -> "WhatsApp mein message taiyar hai. Check karke Send dabao."
            AssistantIntent.SEND_SMS -> "SMS draft ready kar diya hai."
            AssistantIntent.SEND_EMAIL -> "Email draft open kar diya."
            AssistantIntent.SEARCH_YOUTUBE -> "YouTube par search kar rahi hoon."
            else -> "Ho gaya!"
        }
    }

    /**
     * Formats recent conversation turns to inject as background context
     * into Gemini Live setup instructions and prompt continuation.
     */
    fun formatPromptContext(limit: Int = 10): String {
        val recent = _messages.value.takeLast(limit)
        if (recent.isEmpty()) return ""

        val sb = StringBuilder("PAST CONVERSATION HISTORY (BACKGROUND REFERENCE ONLY):\n")
        recent.forEach { msg ->
            val speaker = if (msg.isUser) "User" else "Rafel"
            sb.append("- ").append(speaker).append(": \"").append(msg.text).append("\"\n")
        }
        sb.append("\nIMPORTANT CONTINUITY RULES:\n")
        sb.append("1. The above turns are past conversation history for background reference.\n")
        sb.append("2. NEVER answer an old question again. Always address the user's latest incoming live utterance directly.\n")
        sb.append("3. If the user asks a completely new unrelated question, switch topics immediately without dragging in old context.\n")
        sb.append("4. Use previous messages only when the user explicitly refers to them (e.g. 'woh', 'uske baare mein', 'maine kya kaha tha').")
        return sb.toString()
    }

    fun getDebugHistoryRedacted(limit: Int = 10): List<String> {
        val recent = _messages.value.takeLast(limit)
        return recent.map { msg ->
            val speaker = if (msg.isUser) "USER" else "RAFEL"
            val redactedText = msg.text
                .replace(Regex("\\b[6-9]\\d{9}\\b"), "[PHONE_REDACTED]")
                .replace(Regex("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b"), "[EMAIL_REDACTED]")
            "$speaker: \"$redactedText\""
        }
    }

    fun clearAllHistory() {
        _messages.value = emptyList()
        scope.launch {
            try {
                memoryDao.clearAllTurns()
            } catch (e: Exception) {
                RafelLogger.logError("Failed to clear memory database", e)
            }
        }
    }

    private fun appendMessage(msg: UnifiedMessage) {
        val current = _messages.value
        val updated = if (current.size >= 80) {
            current.drop(current.size - 79) + msg
        } else {
            current + msg
        }
        _messages.value = updated
    }

    private fun persistTurn(role: String, text: String, messageType: String, timestamp: Long) {
        scope.launch {
            try {
                memoryDao.insertTurn(
                    ConversationTurnEntity(
                        role = role,
                        text = text,
                        messageType = messageType,
                        timestamp = timestamp
                    )
                )
            } catch (e: Exception) {
                RafelLogger.logError("Failed to persist conversation turn", e)
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: RafelConversationManager? = null

        fun getInstance(context: Context): RafelConversationManager {
            return INSTANCE ?: synchronized(this) {
                val inst = RafelConversationManager(context.applicationContext)
                INSTANCE = inst
                inst
            }
        }
    }
}
