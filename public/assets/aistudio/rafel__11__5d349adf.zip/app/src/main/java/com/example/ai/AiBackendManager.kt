package com.example.ai

import android.content.Context
import com.example.voice.RafelLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Coordinates AI backend connection state for Rafel (Gemini Live).
 */
class AiBackendManager(
    private val context: Context,
    private val geminiKeyProvider: () -> String?
) {
    private val _activeBackend = MutableStateFlow(AiBackend.GEMINI_LIVE)
    val activeBackend: StateFlow<AiBackend> = _activeBackend.asStateFlow()

    private val _connectionStatus = MutableStateFlow("GEMINI_DISCONNECTED")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    var onBackendChanged: ((AiBackend) -> Unit)? = null

    init {
        updateActiveBackend()
    }

    fun updateActiveBackend() {
        _activeBackend.value = AiBackend.GEMINI_LIVE
        RafelLogger.logLive("AI Backend: ${AiBackend.GEMINI_LIVE}")
    }

    fun setGeminiConnected(connected: Boolean) {
        _connectionStatus.value = if (connected) "GEMINI_CONNECTED" else "GEMINI_DISCONNECTED"
    }

    fun isGeminiActive(): Boolean = true
}

