package com.example.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.RafelForegroundService
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.floating.RafelFloatingService
import com.example.util.PermissionHelper
import com.example.util.PermissionItem
import com.example.voice.VoiceConfig

private val SettingsBg = Color(0xFF07060A)
private val SettingsGold = Color(0xFFFFB300)
private val SettingsAmber = Color(0xFFFFD54F)
private val SettingsCardBg = Color(0xFF130F1C).copy(alpha = 0.85f)
private val SettingsBorder = Color(0xFFFFB300).copy(alpha = 0.2f)
private val StatusGreen = Color(0xFF00E676)
private val StatusOrange = Color(0xFFFF9100)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RafelSettingsScreen(
    onNavigateBack: () -> Unit,
    onRelaunchSetup: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("RafelPrefs", Context.MODE_PRIVATE) }

    var selectedTab by remember { mutableStateOf("all") } // "all", "privacy", "edge_lighting"

    // If edge lighting settings is selected, show dedicated screen
    if (selectedTab == "edge_lighting") {
        EdgeLightingSettingsScreen(
            onNavigateBack = { selectedTab = "all" }
        )
        return
    }

    // Live states
    val isMicMuted by RafelForegroundService.isMicMutedFlow.collectAsState()
    val proactivePrefs = remember { context.getSharedPreferences("rafel_proactive_prefs", Context.MODE_PRIVATE) }
    var isProactiveEnabled by remember { mutableStateOf(proactivePrefs.getBoolean("proactive_enabled", true)) }
    var isFloatingActive by remember { mutableStateOf(RafelFloatingService.isRunning(context) && PermissionHelper.isOverlayGranted(context)) }
    var isAccessibilityOn by remember { mutableStateOf(PermissionHelper.isAccessibilityEnabled(context)) }
    var isNotifAccessOn by remember { mutableStateOf(PermissionHelper.isNotificationAccessGranted(context)) }
    var isBatteryOptimized by remember { mutableStateOf(PermissionHelper.isBatteryOptimizationIgnored(context)) }
    var permissionsList by remember { mutableStateOf(PermissionHelper.getAll10Permissions(context)) }

    fun refreshAll() {
        isFloatingActive = RafelFloatingService.isRunning(context) && PermissionHelper.isOverlayGranted(context)
        isAccessibilityOn = PermissionHelper.isAccessibilityEnabled(context)
        isNotifAccessOn = PermissionHelper.isNotificationAccessGranted(context)
        isBatteryOptimized = PermissionHelper.isBatteryOptimizationIgnored(context)
        permissionsList = PermissionHelper.getAll10Permissions(context)
    }

    Scaffold(
        containerColor = SettingsBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (selectedTab == "privacy") "Privacy & Security" else "Rafel Settings",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedTab == "privacy") {
                            selectedTab = "all"
                        } else {
                            onNavigateBack()
                        }
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { refreshAll() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = SettingsAmber)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SettingsBg)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (selectedTab == "privacy") {
                PrivacyDashboard(
                    permissionsList = permissionsList,
                    onOpenAppSettings = { PermissionHelper.openAppSettings(context) }
                )
            } else {
                MainSettingsList(
                    permissionsList = permissionsList,
                    isMicMuted = isMicMuted,
                    isFloatingActive = isFloatingActive,
                    isAccessibilityOn = isAccessibilityOn,
                    isNotifAccessOn = isNotifAccessOn,
                    isBatteryOptimized = isBatteryOptimized,
                    onToggleFloating = { enable ->
                        if (enable) {
                            if (PermissionHelper.isOverlayGranted(context)) {
                                RafelFloatingService.start(context)
                                isFloatingActive = true
                            } else {
                                PermissionHelper.openOverlaySettings(context)
                            }
                        } else {
                            RafelFloatingService.stop(context)
                            isFloatingActive = false
                        }
                    },
                    onToggleMic = {
                        RafelForegroundService.toggleMicMute()
                    },
                    onOpenAccessibility = { PermissionHelper.openAccessibilitySettings(context) },
                    onOpenNotifications = { PermissionHelper.openNotificationListenerSettings(context) },
                    onOpenBattery = { PermissionHelper.openBatterySettings(context) },
                    onOpenDefaultAssistant = { PermissionHelper.openDefaultAssistantSettings(context) },
                    onOpenPrivacy = { selectedTab = "privacy" },
                    onOpenEdgeLighting = { selectedTab = "edge_lighting" },
                    onRelaunchSetup = onRelaunchSetup
                )
            }
        }
    }
}

@Composable
private fun MainSettingsList(
    permissionsList: List<PermissionItem>,
    isMicMuted: Boolean,
    isFloatingActive: Boolean,
    isAccessibilityOn: Boolean,
    isNotifAccessOn: Boolean,
    isBatteryOptimized: Boolean,
    onToggleFloating: (Boolean) -> Unit,
    onToggleMic: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenDefaultAssistant: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenEdgeLighting: () -> Unit,
    onRelaunchSetup: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("RafelPrefs", Context.MODE_PRIVATE) }
    val proactivePrefs = remember { context.getSharedPreferences("rafel_proactive_prefs", Context.MODE_PRIVATE) }
    var isProactiveEnabled by remember { mutableStateOf(proactivePrefs.getBoolean("proactive_enabled", true)) }
    val grantedCount = permissionsList.count { it.isGranted }

    var geminiKey by remember {
        val buildKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        val saved = if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") buildKey else prefs.getString("api_key", "") ?: ""
        mutableStateOf(saved)
    }
    var showApiKeyDialog by remember { mutableStateOf(false) }

    if (showApiKeyDialog) {
        var tempGemini by remember { mutableStateOf(geminiKey) }

        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            containerColor = Color(0xFF130F1C),
            shape = RoundedCornerShape(20.dp),
            title = {
                Text("Gemini API Key", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Your Gemini API Key is securely stored and used exclusively for Gemini Live native audio streaming.",
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 12.sp
                    )

                    // Gemini API Key
                    Column {
                        Text("Gemini API Key", color = SettingsAmber, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = tempGemini,
                            onValueChange = { tempGemini = it },
                            placeholder = { Text("AIza...", color = Color.White.copy(alpha = 0.3f)) },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SettingsGold,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        prefs.edit()
                            .putString("api_key", tempGemini)
                            .putString("gemini_api_key", tempGemini)
                            .apply()
                        geminiKey = tempGemini
                        RafelForegroundService.activeBackendManager?.updateActiveBackend()
                        showApiKeyDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SettingsGold)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Section: Appearance
        item {
            SettingsCategoryHeader("APPEARANCE")
            SettingsCard {
                SettingsRowWithIcon(
                    icon = Icons.Default.BlurOn,
                    title = "Edge Lighting",
                    subtitle = "Side glowing borders, colors, animations & bloom",
                    badgeText = "CUSTOMIZE",
                    isBadgePositive = true,
                    onClick = onOpenEdgeLighting
                )
            }
        }

        // Section: AI Backend & Routing
        item {
            SettingsCategoryHeader("GEMINI LIVE AI ENGINE")
            SettingsCard {
                SettingsRowWithIcon(
                    icon = Icons.Default.Psychology,
                    title = "Gemini Live",
                    subtitle = "${VoiceConfig.GEMINI_LIVE_MODEL} • ${if (geminiKey.isNotBlank()) "Key Ready" else "Key Needed"}",
                    badgeText = if (geminiKey.isNotBlank()) "ONLINE" else "SETUP",
                    isBadgePositive = geminiKey.isNotBlank(),
                    onClick = { showApiKeyDialog = true }
                )

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                OutlinedButton(
                    onClick = { showApiKeyDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SettingsAmber),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SettingsAmber.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Configure Gemini API Key", fontSize = 13.sp)
                }
            }
        }

        // Section: Real-Device Speaker & Pipeline Diagnostics (AudioTrack 24kHz)
        item {
            SettingsCategoryHeader("AUDIO HARDWARE & STREAM DIAGNOSTICS")
            AudioHardwareDiagnosisCard()
        }

        // Section: Microphone Control
        item {
            SettingsCategoryHeader("MICROPHONE")
            SettingsCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SettingsGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (isMicMuted) StatusOrange else SettingsAmber,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Microphone Status",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isMicMuted) "MIC OFF — Voice capture paused" else "MIC ON — Ready for speech & barge-in",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = !isMicMuted,
                        onCheckedChange = { onToggleMic() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = SettingsGold,
                            uncheckedTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }

        // Section: Phone Control & Permissions
        item {
            SettingsCategoryHeader("PHONE CALLING & PERMISSIONS")
            SettingsCard {
                SettingsRowWithIcon(
                    icon = Icons.Default.Security,
                    title = "Android Permissions",
                    subtitle = "$grantedCount of ${permissionsList.size} permissions granted",
                    badgeText = if (grantedCount == permissionsList.size) "ALL GRANTED" else "$grantedCount/${permissionsList.size}",
                    isBadgePositive = grantedCount >= 7,
                    onClick = onOpenPrivacy
                )
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                var isDirectCallingEnabled by remember { mutableStateOf(prefs.getBoolean("direct_calling_enabled", false)) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SettingsGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = SettingsAmber, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Direct Phone Calling",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isDirectCallingEnabled) "Direct Call (CALL_PHONE) active" else "Dialer Safe Mode: Opens dialer prefilled",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = isDirectCallingEnabled,
                        onCheckedChange = { newVal ->
                            isDirectCallingEnabled = newVal
                            prefs.edit().putBoolean("direct_calling_enabled", newVal).apply()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = SettingsGold,
                            uncheckedTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SettingsGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = SettingsAmber, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Proactive Conversation",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isProactiveEnabled) "Follows up after 3-5s of silence" else "Disabled: Responds only to questions",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = isProactiveEnabled,
                        onCheckedChange = { newVal ->
                            isProactiveEnabled = newVal
                            proactivePrefs.edit().putBoolean("proactive_enabled", newVal).apply()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = SettingsGold,
                            uncheckedTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }

        // Section: Accessibility & Assistant
        item {
            SettingsCategoryHeader("ASSISTANT CAPABILITIES")
            SettingsCard {
                // Accessibility
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenAccessibility() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SettingsGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AccessibilityNew, contentDescription = null, tint = SettingsAmber, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Accessibility Automation", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(text = "Tap on-screen text and navigate apps on command", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                    }
                    Surface(
                        color = if (isAccessibilityOn) StatusGreen.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (isAccessibilityOn) "ON" else "OFF",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAccessibilityOn) StatusGreen else Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                // Floating Assistant
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SettingsGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, tint = SettingsAmber, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Floating Rafel Assistant", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(text = "Show draggable bubble over other apps", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                    }
                    Switch(
                        checked = isFloatingActive,
                        onCheckedChange = { onToggleFloating(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = SettingsGold,
                            uncheckedTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                // Default Digital Assistant
                SettingsRowWithIcon(
                    icon = Icons.Default.Assistant,
                    title = "Default Digital Assistant",
                    subtitle = "Launch Rafel with assistant gesture or power button",
                    badgeText = "CONFIGURE",
                    isBadgePositive = true,
                    onClick = onOpenDefaultAssistant
                )

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                // Battery / Background
                SettingsRowWithIcon(
                    icon = Icons.Default.BatteryChargingFull,
                    title = "Background Battery Optimization",
                    subtitle = if (isBatteryOptimized) "Disabled (Rafel runs reliably in background)" else "Restricted by system",
                    badgeText = if (isBatteryOptimized) "OPTIMIZED" else "RESTRICTED",
                    isBadgePositive = isBatteryOptimized,
                    onClick = onOpenBattery
                )

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))

                // Notification Access
                SettingsRowWithIcon(
                    icon = Icons.Default.NotificationsActive,
                    title = "Notification Listener",
                    subtitle = "Allows Rafel to read requested notifications",
                    badgeText = if (isNotifAccessOn) "ON" else "OFF",
                    isBadgePositive = isNotifAccessOn,
                    onClick = onOpenNotifications
                )
            }
        }

        // Section: Privacy & About
        item {
            SettingsCategoryHeader("PRIVACY & APP")
            SettingsCard {
                SettingsRowWithIcon(
                    icon = Icons.Default.Shield,
                    title = "Privacy & Data Transparency",
                    subtitle = "View full explanation of how your data and permissions are protected",
                    badgeText = "VIEW",
                    isBadgePositive = true,
                    onClick = onOpenPrivacy
                )
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))
                SettingsRowWithIcon(
                    icon = Icons.Default.RestartAlt,
                    title = "Relaunch Setup Wizard",
                    subtitle = "Run through the 3-step setup flow again",
                    badgeText = "SETUP",
                    isBadgePositive = false,
                    onClick = onRelaunchSetup
                )
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 8.dp))
                SettingsRowWithIcon(
                    icon = Icons.Default.Info,
                    title = "About Rafel",
                    subtitle = "Version 1.0.1 • Real-time AI Voice Assistant",
                    badgeText = "v1.0.1",
                    isBadgePositive = true
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// ==========================================
// PRIVACY DASHBOARD (PART 12)
// ==========================================

@Composable
private fun PrivacyDashboard(
    permissionsList: List<PermissionItem>,
    onOpenAppSettings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SettingsBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = SettingsCardBg),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Rafel Privacy Promise", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Zero hidden surveillance, background spying, or secret recordings.\n" +
                                "• Microphone audio is only streamed while active conversation is in progress.\n" +
                                "• Sensitive actions (calls, SMS, file changes) require user confirmation.\n" +
                                "• Accessibility and camera are only used on explicit user voice commands.\n" +
                                "• You can revoke any permission anytime directly in Android Settings.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.78f),
                        lineHeight = 19.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = onOpenAppSettings,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SettingsAmber),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SettingsAmber.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open Android App Settings to Revoke Permissions")
                    }
                }
            }
        }

        item {
            Text(
                text = "ACTIVE PERMISSION USAGE",
                color = SettingsGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(permissionsList, key = { it.id }) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = SettingsCardBg),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = if (item.isGranted) StatusGreen.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (item.isGranted) "ALLOWED" else "DENIED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.isGranted) StatusGreen else Color.White.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(text = item.description, fontSize = 12.sp, color = Color.White.copy(alpha = 0.65f))
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// Helpers
@Composable
private fun SettingsCategoryHeader(text: String) {
    Text(
        text = text,
        color = SettingsGold,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SettingsBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SettingsCardBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

@Composable
private fun SettingsRowWithIcon(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badgeText: String,
    isBadgePositive: Boolean,
    onClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(SettingsGold.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = SettingsAmber, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(text = subtitle, color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
        }
        Surface(
            color = if (isBadgePositive) StatusGreen.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.12f),
            shape = RoundedCornerShape(6.dp)
        ) {
            Text(
                text = badgeText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isBadgePositive) StatusGreen else Color.White.copy(alpha = 0.6f),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
        }
    }
}

// ==========================================
// REAL-DEVICE AUDIO DIAGNOSTICS CARD
// ==========================================

@Composable
private fun AudioHardwareDiagnosisCard() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val diagManager = remember { com.example.voice.AudioDiagnosisManager(context) }
    val isTesting by diagManager.isTesting.collectAsState()
    val logs by diagManager.diagnosisLog.collectAsState()
    var speakerTestStatus by remember { mutableStateOf<String?>(null) }
    var liveTestStatus by remember { mutableStateOf<String?>(null) }

    SettingsCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E5FF).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "Test Speaker & AudioTrack", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = "Plays 24kHz PCM tone through exact live AudioTrack", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    coroutineScope.launch {
                        val res = diagManager.runTest1LocalPlayback()
                        speakerTestStatus = res.writeResult
                    }
                },
                enabled = !isTesting,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("test_speaker_button"),
                contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)
            ) {
                Text("TEST SPEAKER", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            OutlinedButton(
                onClick = {
                    coroutineScope.launch {
                        diagManager.runFullDiagnosis()
                    }
                },
                enabled = !isTesting,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = SettingsAmber),
                border = androidx.compose.foundation.BorderStroke(1.dp, SettingsAmber.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1.2f),
                contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)
            ) {
                if (isTesting) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = SettingsAmber)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Testing...", fontSize = 11.sp)
                } else {
                    Text("Run 4-Stage Test", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        speakerTestStatus?.let { status ->
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF00E676).copy(alpha = 0.15f))
                    .border(1.dp, Color(0xFF00E676).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = status,
                    color = Color(0xFF00E676),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    coroutineScope.launch {
                        val res = diagManager.runConnectLiveMinimal()
                        liveTestStatus = if (res.isSuccess) res.writeResult else (res.errorMessage ?: res.writeResult)
                    }
                },
                enabled = !isTesting,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF).copy(alpha = 0.85f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("connect_live_button"),
                contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)
            ) {
                Text("CONNECT LIVE MINIMAL", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }

            Button(
                onClick = {
                    coroutineScope.launch {
                        val res = diagManager.runSendHelloRafelTest()
                        liveTestStatus = if (res.isSuccess) res.writeResult else (res.errorMessage ?: res.writeResult)
                    }
                },
                enabled = !isTesting,
                colors = ButtonDefaults.buttonColors(containerColor = SettingsAmber),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("send_text_test_button"),
                contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp)
            ) {
                Text("SEND HELLO RAFEL", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Dedicated Background Voice Test Button
        Button(
            onClick = {
                coroutineScope.launch {
                    val res = diagManager.runBackgroundVoiceTest()
                    liveTestStatus = if (res.isSuccess) res.writeResult else (res.errorMessage ?: res.writeResult)
                }
            },
            enabled = !isTesting,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("background_voice_test_button"),
            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 8.dp)
        ) {
            Text("BACKGROUND VOICE TEST", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Background Execution & Battery Optimization Information
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E1829))
                .border(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "Background Voice Execution",
                color = Color(0xFFB388FF),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Rafel uses an Android Foreground Service with microphone type to keep Gemini Live active when minimized or screen turns off. If your phone manufacturer (MIUI, EMUI, ColorOS, OneUI) enforces aggressive battery killing, please disable battery optimization manually in system settings.",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedButton(
                onClick = {
                    try {
                        val intent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        try {
                            val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        } catch (ex: Exception) {
                            Toast.makeText(context, "Open Settings > Apps > Rafel > Battery to disable optimization", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB388FF)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB388FF).copy(alpha = 0.5f)),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Manage Battery Settings", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        liveTestStatus?.let { status ->
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (status.contains("ERROR") || status.contains("FAILED") || status.contains("missing", ignoreCase = true)) Color(0xFFFF5252).copy(alpha = 0.15f) else Color(0xFF00E676).copy(alpha = 0.15f))
                    .border(1.dp, if (status.contains("ERROR") || status.contains("FAILED") || status.contains("missing", ignoreCase = true)) Color(0xFFFF5252).copy(alpha = 0.5f) else Color(0xFF00E676).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = status,
                    color = if (status.contains("ERROR") || status.contains("FAILED") || status.contains("missing", ignoreCase = true)) Color(0xFFFF8A80) else Color(0xFF00E676),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        // Live Diagnostic Log Table
        if (logs.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.45f))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "DIAGNOSTIC REPORT",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                logs.forEachIndexed { idx, item ->
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (item.isSuccess) "✓ PASS" else "✗ FAIL",
                                color = if (item.isSuccess) StatusGreen else Color(0xFFFF5252),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.testName,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "• Track State: ${item.audioTrackState} | PlayState: ${item.audioTrackPlayState}\n" +
                                   "• Output Device: ${item.audioOutputDevice} (${item.routingType})\n" +
                                   "• Audio Mode: ${item.audioManagerMode} | Buffer: ${item.bufferCapacity}\n" +
                                   "• Received: ${item.receivedBytes}b | Decoded PCM: ${item.decodedPcmBytes}b\n" +
                                   "• Result: ${item.writeResult}" +
                                   (if (item.errorMessage != null) "\n• Error: ${item.errorMessage}" else ""),
                            color = Color.White.copy(alpha = 0.72f),
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier.padding(start = 12.dp, top = 2.dp)
                        )
                    }
                    if (idx < logs.size - 1) {
                        HorizontalDivider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }
    }
}

