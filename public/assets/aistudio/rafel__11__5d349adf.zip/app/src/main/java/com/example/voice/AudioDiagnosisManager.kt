package com.example.voice

import android.content.Context
import android.media.AudioTrack
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import kotlin.math.sin

/**
 * Result data holder for Speaker and Audio Diagnostic Tests.
 */
data class AudioDiagnosisResult(
    val testName: String,
    val isSuccess: Boolean,
    val receivedBytes: Int = 0,
    val decodedPcmBytes: Int = 0,
    val audioTrackState: String = "UNKNOWN",
    val audioTrackPlayState: String = "UNKNOWN",
    val audioSessionId: Int = -1,
    val bufferCapacity: String = "UNKNOWN",
    val audioOutputDevice: String = "DEFAULT",
    val audioManagerMode: String = "NORMAL",
    val routingType: String = "SPEAKER",
    val writeResult: String = "NONE",
    val errorMessage: String? = null,
    val details: String = ""
)

/**
 * Android Device Audio Diagnostic Engine.
 * Tests each segment of the audio output pipeline on the real hardware AudioTrack:
 * 1. Test local AudioTrack playback (24kHz 16-bit Mono PCM synthesized tone)
 * 2. Test Gemini audio reception & simulated Base64 reception
 * 3. Test Gemini audio decoding (Base64 -> 24kHz 16-bit PCM alignment)
 * 4. Test Gemini PCM -> AudioTrack playback through AudioPlaybackManager
 */
class AudioDiagnosisManager(
    private val context: Context,
    private val playbackManager: AudioPlaybackManager? = null
) {
    private val _diagnosisLog = MutableStateFlow<List<AudioDiagnosisResult>>(emptyList())
    val diagnosisLog: StateFlow<List<AudioDiagnosisResult>> = _diagnosisLog.asStateFlow()

    private val _isTesting = MutableStateFlow(false)
    val isTesting: StateFlow<Boolean> = _isTesting.asStateFlow()

    /**
     * Generates a clean 24kHz 16-bit mono sine wave PCM test tone (e.g. 440Hz, 880Hz chime for 500ms).
     */
    fun generateTestPcmTone(durationMs: Int = 500, freqHz: Double = 523.25): ByteArray {
        val sampleRate = VoiceConfig.SAMPLE_RATE_OUT // 24000
        val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcmBytes = ByteArray(totalSamples * 2)

        for (i in 0 until totalSamples) {
            val angle = 2.0 * Math.PI * i / (sampleRate / freqHz)
            // Apply slight envelope (fade in/out) to avoid clicks
            val envelope = when {
                i < 480 -> i / 480.0
                i > totalSamples - 480 -> (totalSamples - i) / 480.0
                else -> 1.0
            }
            val sampleVal = (sin(angle) * 16000.0 * envelope).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            val low = (sampleVal and 0xFF).toByte()
            val high = ((sampleVal shr 8) and 0xFF).toByte()
            pcmBytes[i * 2] = low
            pcmBytes[i * 2 + 1] = high
        }
        return pcmBytes
    }

    /**
     * TEST 1: Test Local AudioTrack Playback
     * Directly plays a 24kHz PCM test tone through AudioPlaybackManager and inspects hardware state.
     */
    suspend fun runTest1LocalPlayback(): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val tonePcm = generateTestPcmTone(durationMs = 1000, freqHz = 1000.0) // 1 second, 1000 Hz sine wave tone
        val pManager = playbackManager ?: AudioPlaybackManager(
            context = context,
            onPlaybackStarted = {},
            onPlaybackFinished = {}
        )

        try {
            val genId = System.currentTimeMillis()
            pManager.prepareForPlayback()
            pManager.enqueueChunk(genId, tonePcm)
            Thread.sleep(50)
            val trackState = pManager.getAudioTrackStateString()
            val playState = pManager.getAudioTrackPlayStateString()
            pManager.markTurnComplete(genId)

            val hwReport = pManager.getAudioHardwareReport()

            val res = AudioDiagnosisResult(
                testName = "1. Local AudioTrack Playback (24kHz Sine Tone)",
                isSuccess = true,
                receivedBytes = tonePcm.size,
                decodedPcmBytes = tonePcm.size,
                audioTrackState = trackState,
                audioTrackPlayState = playState,
                audioSessionId = 0,
                bufferCapacity = "${tonePcm.size} bytes",
                audioOutputDevice = "Speaker / Active Audio Output",
                audioManagerMode = "MODE_NORMAL",
                routingType = "BUILTIN_SPEAKER",
                writeResult = "SPEAKER TEST PLAYED",
                details = hwReport
            )
            appendResult(res)
            return@withContext res
        } catch (e: Exception) {
            val err = AudioDiagnosisResult(
                testName = "1. Local AudioTrack Playback",
                isSuccess = false,
                receivedBytes = tonePcm.size,
                decodedPcmBytes = 0,
                errorMessage = e.message ?: e.toString(),
                details = "AudioTrack playback threw exception: ${e.localizedMessage}"
            )
            appendResult(err)
            return@withContext err
        }
    }

    /**
     * TEST 2: Test Gemini Audio Reception
     * Tests WebSocket / simulated streaming frame reception from Gemini Live structure.
     */
    suspend fun runTest2GeminiReception(): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val samplePcm = generateTestPcmTone(durationMs = 300, freqHz = 659.25) // E5
        val base64Payload = Base64.encodeToString(samplePcm, Base64.NO_WRAP)
        val mockJson = "{\"serverContent\":{\"modelTurn\":{\"parts\":[{\"inlineData\":{\"mimeType\":\"audio/pcm;rate=24000\",\"data\":\"$base64Payload\"}}]}}}"

        val receivedBytes = mockJson.toByteArray(Charsets.UTF_8).size
        val hasInlineData = mockJson.contains("inlineData") && mockJson.contains("mimeType")

        val res = AudioDiagnosisResult(
            testName = "2. Gemini Live Audio Reception Protocol",
            isSuccess = hasInlineData,
            receivedBytes = receivedBytes,
            decodedPcmBytes = 0,
            writeResult = "JSON protocol valid, mimeType=audio/pcm;rate=24000",
            details = "Received WebSocket serverContent payload (${receivedBytes} bytes JSON, Base64 length=${base64Payload.length})."
        )
        appendResult(res)
        return@withContext res
    }

    /**
     * TEST 3: Test Gemini Audio Decoding
     * Tests Base64 decoding and 16-bit PCM alignment from Gemini response stream.
     */
    suspend fun runTest3GeminiDecoding(): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val originalPcm = generateTestPcmTone(durationMs = 400, freqHz = 783.99) // G5
        val base64String = Base64.encodeToString(originalPcm, Base64.NO_WRAP)

        val t0 = System.currentTimeMillis()
        val decodedBytes = Base64.decode(base64String, Base64.NO_WRAP)
        val elapsed = System.currentTimeMillis() - t0

        val isEven = decodedBytes.size % 2 == 0
        val isMatch = decodedBytes.size == originalPcm.size

        val res = AudioDiagnosisResult(
            testName = "3. Gemini Audio Decoding & Frame Alignment",
            isSuccess = isEven && isMatch,
            receivedBytes = base64String.length,
            decodedPcmBytes = decodedBytes.size,
            writeResult = "Decoded in ${elapsed}ms, 16-bit frame aligned (isEven=$isEven)",
            details = "Input: ${base64String.length} chars Base64 -> Output: ${decodedBytes.size} bytes PCM 16-bit (${decodedBytes.size / 2} samples)."
        )
        appendResult(res)
        return@withContext res
    }

    /**
     * TEST 4: Test Gemini PCM -> AudioTrack End-to-End Playback
     * Simulates receiving a Base64 chunk from Gemini Live, decoding it, and streaming through AudioPlaybackManager.
     */
    suspend fun runTest4GeminiPcmToAudioTrack(): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val testPcm = generateTestPcmTone(durationMs = 700, freqHz = 880.0) // A5 note (crystal clear chime)
        val base64Payload = Base64.encodeToString(testPcm, Base64.NO_WRAP)

        val pManager = playbackManager ?: AudioPlaybackManager(
            context = context,
            onPlaybackStarted = {},
            onPlaybackFinished = {}
        )

        try {
            // 1. Decode
            val decodedPcm = Base64.decode(base64Payload, Base64.NO_WRAP)

            // 2. Play via manager
            val genId = System.currentTimeMillis()
            pManager.prepareForPlayback()
            pManager.enqueueChunk(genId, decodedPcm)
            Thread.sleep(50)
            val trackState = pManager.getAudioTrackStateString()
            val playState = pManager.getAudioTrackPlayStateString()
            pManager.markTurnComplete(genId)

            val hwReport = pManager.getAudioHardwareReport()
            RafelLogger.logDiagnostic("[SPEAKER_TEST 2 - Gemini PCM] Hardware Report:\n$hwReport")

            val res = AudioDiagnosisResult(
                testName = "4. Gemini PCM -> AudioTrack End-to-End Playback",
                isSuccess = true,
                receivedBytes = base64Payload.length,
                decodedPcmBytes = decodedPcm.size,
                audioTrackState = trackState,
                audioTrackPlayState = playState,
                audioSessionId = 0,
                bufferCapacity = "${decodedPcm.size} bytes",
                audioOutputDevice = "Speaker / Active Audio Output",
                audioManagerMode = "MODE_NORMAL",
                routingType = "BUILTIN_SPEAKER",
                writeResult = "Enqueued and streamed ${decodedPcm.size} bytes (700ms at 24kHz)",
                details = hwReport
            )
            appendResult(res)
            return@withContext res
        } catch (e: Exception) {
            val err = AudioDiagnosisResult(
                testName = "4. Gemini PCM -> AudioTrack Playback",
                isSuccess = false,
                receivedBytes = base64Payload.length,
                decodedPcmBytes = 0,
                errorMessage = e.message ?: e.toString(),
                details = "End-to-end playback failed: ${e.localizedMessage}"
            )
            appendResult(err)
            return@withContext err
        }
    }

    private fun getEffectiveApiKey(): String {
        val buildKey = try { BuildConfig.GEMINI_API_KEY } catch (_: Exception) { "" }
        val prefs = context.getSharedPreferences("RafelPrefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("api_key", "") ?: prefs.getString("gemini_api_key", "") ?: ""
        return if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY" && buildKey != "YOUR_API_KEY") {
            buildKey
        } else {
            saved
        }
    }

    /**
     * TEST 1: CONNECT LIVE MINIMAL (30-Second Liveness Test)
     * Connects, sends minimal setup, waits for setupComplete, and verifies the session stays alive for 30 seconds.
     */
    suspend fun runConnectLiveMinimal(customKey: String? = null): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val apiKey = customKey?.takeIf { it.isNotBlank() } ?: getEffectiveApiKey()

        if (apiKey.isBlank()) {
            val err = AudioDiagnosisResult(
                testName = "TEST 1: CONNECT LIVE MINIMAL",
                isSuccess = false,
                errorMessage = "Gemini Live Error:\nHTTP/code: 401\nmessage: API key missing\ncloseCode: 401\ncloseReason: API Key Missing",
                writeResult = "API KEY MISSING"
            )
            appendResult(err)
            return@withContext err
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(15, TimeUnit.SECONDS)
            .build()

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        val completable = CompletableDeferred<AudioDiagnosisResult>()
        var setupReceived = false
        var lastMsg = "NONE"

        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                android.util.Log.i("RAFEL-TEST", "[WS_OPEN] Minimal test socket connected. Sending minimal setup...")
                val setupMsg = "{\"setup\":{\"model\":\"${VoiceConfig.GEMINI_LIVE_MODEL}\",\"generationConfig\":{\"responseModalities\":[\"AUDIO\"],\"speechConfig\":{\"voiceConfig\":{\"prebuiltVoiceConfig\":{\"voiceName\":\"${VoiceConfig.GEMINI_VOICE_NAME}\"}}}}}}"
                webSocket.send(setupMsg)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                lastMsg = text.take(100)
                android.util.Log.i("RAFEL-TEST", "[WS_MESSAGE] $lastMsg")
                if (text.contains("setupComplete") || text.contains("setup_complete")) {
                    setupReceived = true
                    android.util.Log.i("RAFEL-TEST", "CONNECTED\nSETUP COMPLETE\nWaiting 30 seconds for liveness check...")
                } else if (text.contains("error")) {
                    val code = Regex("\"code\"\\s*:\\s*(\\d+)").find(text)?.groupValues?.get(1) ?: "UNKNOWN"
                    val msg = Regex("\"message\"\\s*:\\s*\"([^\"]+)\"").find(text)?.groupValues?.get(1) ?: text
                    completable.complete(
                        AudioDiagnosisResult(
                            testName = "TEST 1: CONNECT LIVE MINIMAL",
                            isSuccess = false,
                            errorMessage = "Gemini Live Error:\nHTTP/code: $code\nmessage: $msg\ncloseCode: $code\ncloseReason: Server Error",
                            writeResult = "SERVER ERROR: $code"
                        )
                    )
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                android.util.Log.w("RAFEL-TEST", "[WS_CLOSING] code=$code reason=$reason setupComplete=$setupReceived")
                if (!completable.isCompleted) {
                    completable.complete(
                        AudioDiagnosisResult(
                            testName = "TEST 1: CONNECT LIVE MINIMAL",
                            isSuccess = false,
                            errorMessage = "Gemini Live Error:\nHTTP/code: $code\nmessage: Closing: $reason\ncloseCode: $code\ncloseReason: $reason",
                            writeResult = "CLOSED PREMATURELY ($code)"
                        )
                    )
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                android.util.Log.w("RAFEL-TEST", "[WS_CLOSED] code=$code reason=$reason setupComplete=$setupReceived")
                if (!completable.isCompleted) {
                    completable.complete(
                        AudioDiagnosisResult(
                            testName = "TEST 1: CONNECT LIVE MINIMAL",
                            isSuccess = false,
                            errorMessage = "Gemini Live Error:\nHTTP/code: $code\nmessage: Closed: $reason\ncloseCode: $code\ncloseReason: $reason",
                            writeResult = "CLOSED PREMATURELY ($code)"
                        )
                    )
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val code = response?.code ?: 0
                val body = try { response?.body?.string() ?: "" } catch (_: Exception) { "" }
                android.util.Log.e("RAFEL-TEST", "[WS_FAILURE] code=$code msg=${t.message} body=$body")
                if (!completable.isCompleted) {
                    completable.complete(
                        AudioDiagnosisResult(
                            testName = "TEST 1: CONNECT LIVE MINIMAL",
                            isSuccess = false,
                            errorMessage = "Gemini Live Error:\nHTTP/code: $code\nmessage: ${t.message} ($body)\ncloseCode: $code\ncloseReason: Connection Failure",
                            writeResult = "FAILURE ($code)"
                        )
                    )
                }
            }
        })

        // Liveness loop: wait up to 35 seconds (must stay alive for 30s)
        try {
            val res = withTimeout(35000L) {
                // Wait for setupComplete (up to 8s)
                val start = System.currentTimeMillis()
                while (!setupReceived && System.currentTimeMillis() - start < 8000L) {
                    if (completable.isCompleted) return@withTimeout completable.await()
                    kotlinx.coroutines.delay(200L)
                }
                if (!setupReceived) {
                    return@withTimeout AudioDiagnosisResult(
                        testName = "TEST 1: CONNECT LIVE MINIMAL",
                        isSuccess = false,
                        errorMessage = "Gemini Live Error:\nHTTP/code: TIMEOUT\nmessage: setupComplete was not received\ncloseCode: 408\ncloseReason: Setup Timeout",
                        writeResult = "SETUP TIMEOUT"
                    )
                }

                // Keep socket alive for 30 seconds
                val livenessStart = System.currentTimeMillis()
                while (System.currentTimeMillis() - livenessStart < 30000L) {
                    if (completable.isCompleted) return@withTimeout completable.await()
                    kotlinx.coroutines.delay(500L)
                }

                android.util.Log.i("RAFEL-TEST", "CONNECTED\nSETUP COMPLETE\nSESSION STILL ALIVE AFTER 30 SECONDS")
                try { ws.close(1000, "30s Liveness passed") } catch (_: Exception) {}

                AudioDiagnosisResult(
                    testName = "TEST 1: CONNECT LIVE MINIMAL",
                    isSuccess = true,
                    writeResult = "SESSION STILL ALIVE AFTER 30 SECONDS",
                    details = "CONNECTED -> SETUP COMPLETE -> SESSION STILL ALIVE AFTER 30 SECONDS"
                )
            }
            appendResult(res)
            return@withContext res
        } catch (e: Exception) {
            try { ws.close(1000, "Error") } catch (_: Exception) {}
            val errRes = AudioDiagnosisResult(
                testName = "TEST 1: CONNECT LIVE MINIMAL",
                isSuccess = false,
                errorMessage = "Gemini Live Error:\nHTTP/code: EXCEPTION\nmessage: ${e.message}\ncloseCode: 500\ncloseReason: Exception",
                writeResult = "EXCEPTION"
            )
            appendResult(errRes)
            return@withContext errRes
        }
    }

    /**
     * TEST 2: SEND HELLO RAFEL
     * Waits for setupComplete, sends clientContent text turn, and validates native 24kHz audio chunk is received & played.
     */
    suspend fun runSendHelloRafelTest(
        customKey: String? = null,
        userText: String = "Hello Rafel",
        testTitle: String = "TEST 2: SEND HELLO RAFEL"
    ): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val apiKey = customKey?.takeIf { it.isNotBlank() } ?: getEffectiveApiKey()

        if (apiKey.isBlank()) {
            val err = AudioDiagnosisResult(
                testName = testTitle,
                isSuccess = false,
                errorMessage = "Gemini Live Error:\nHTTP/code: 401\nmessage: API key missing\ncloseCode: 401\ncloseReason: API Key Missing",
                writeResult = "API KEY MISSING"
            )
            appendResult(err)
            return@withContext err
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        val completable = CompletableDeferred<AudioDiagnosisResult>()
        val pManager = playbackManager ?: AudioPlaybackManager(
            context = context,
            onPlaybackStarted = {},
            onPlaybackFinished = {}
        )

        val genId = System.currentTimeMillis()
        val chunkCount = java.util.concurrent.atomic.AtomicInteger(0)
        val totalAudioBytes = java.util.concurrent.atomic.AtomicLong(0L)
        val turnCompleted = java.util.concurrent.atomic.AtomicBoolean(false)
        val modelTurnStarted = java.util.concurrent.atomic.AtomicBoolean(false)

        val ws = client.newWebSocket(request, object : WebSocketListener() {
            private var setupDone = false

            override fun onOpen(webSocket: WebSocket, response: Response) {
                android.util.Log.i("RAFEL-TEST", "[WS_OPEN] Hello Rafel test connected.")
                val personaPrompt = com.example.ai.RafelPersona.SYSTEM_PROMPT.replace("\"", "\\\"").replace("\n", "\\n")
                val setupMsg = "{\"setup\":{\"model\":\"${VoiceConfig.GEMINI_LIVE_MODEL}\",\"generationConfig\":{\"responseModalities\":[\"AUDIO\"],\"speechConfig\":{\"voiceConfig\":{\"prebuiltVoiceConfig\":{\"voiceName\":\"${VoiceConfig.GEMINI_VOICE_NAME}\"}}}},\"systemInstruction\":{\"parts\":[{\"text\":\"$personaPrompt\"}]}}}"
                webSocket.send(setupMsg)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (!setupDone && (text.contains("setupComplete") || text.contains("setup_complete"))) {
                    setupDone = true
                    android.util.Log.i("RAFEL-TEST", "TEXT_SENT")
                    android.util.Log.i("RAFEL-TURN", "[TURN] USER_TURN_SENT")
                    val escapedText = userText.replace("\"", "\\\"")
                    val textMsg = "{\"clientContent\":{\"turns\":[{\"role\":\"user\",\"parts\":[{\"text\":\"$escapedText\"}]}],\"turnComplete\":true}}"
                    webSocket.send(textMsg)
                    return
                }

                if (text.contains("error")) {
                    val code = Regex("\"code\"\\s*:\\s*(\\d+)").find(text)?.groupValues?.get(1) ?: "UNKNOWN"
                    val msg = Regex("\"message\"\\s*:\\s*\"([^\"]+)\"").find(text)?.groupValues?.get(1) ?: text
                    android.util.Log.e("RAFEL-TEST", "Gemini Live Error: $code - $msg")
                    completable.complete(
                        AudioDiagnosisResult(
                            testName = testTitle,
                            isSuccess = false,
                            errorMessage = "Gemini Live Error:\nHTTP/code: $code\nmessage: $msg\ncloseCode: $code\ncloseReason: Server Error",
                            writeResult = "SERVER ERROR: $code"
                        )
                    )
                    return
                }

                if (text.contains("serverContent") || text.contains("modelTurn")) {
                    android.util.Log.i("RAFEL-TEST", "SERVER_RESPONSE_RECEIVED")
                    if (modelTurnStarted.compareAndSet(false, true)) {
                        android.util.Log.i("RAFEL-TURN", "[TURN] MODEL_TURN_STARTED")
                    }

                    val textMatches = Regex("\"text\"\\s*:\\s*\"([^\"]+)\"").findAll(text)
                    for (tm in textMatches) {
                        val txt = tm.groupValues[1]
                        if (txt.isNotBlank() && !txt.contains("audio/pcm")) {
                            android.util.Log.i("RAFEL-TEST", "MODEL_TEXT_TRANSCRIPT: \"$txt\"")
                        }
                    }

                    if (text.contains("inlineData")) {
                        val dataMatches = Regex("\"data\"\\s*:\\s*\"([^\"]+)\"").findAll(text)
                        for (match in dataMatches) {
                            val dataBase64 = match.groupValues[1]
                            if (dataBase64.isNotEmpty()) {
                                try {
                                    val pcm = Base64.decode(dataBase64, Base64.NO_WRAP)
                                    val c = chunkCount.incrementAndGet()
                                    val tot = totalAudioBytes.addAndGet(pcm.size.toLong())

                                    android.util.Log.i("RAFEL-TEST", "AUDIO_CHUNK_RECEIVED")
                                    android.util.Log.i("RAFEL-TEST", "AUDIO_BYTES: $tot")
                                    android.util.Log.i("RAFEL-TEST", "AUDIO_MIME_TYPE: audio/pcm;rate=24000")
                                    android.util.Log.i("RAFEL-AUDIO", "[AUDIO] CHUNK #$c")
                                    android.util.Log.i("RAFEL-AUDIO", "[AUDIO] totalChunks: $c")
                                    android.util.Log.i("RAFEL-AUDIO", "[AUDIO] totalBytes: $tot")

                                    pManager.prepareForPlayback()
                                    pManager.enqueueChunk(genId, pcm)
                                } catch (e: Exception) {
                                    android.util.Log.e("RAFEL-TEST", "Audio decode error: ${e.message}")
                                }
                            }
                        }
                    }

                    val isComplete = text.contains("\"turnComplete\":true") ||
                            text.contains("\"turnComplete\": true") ||
                            text.contains("\"turn_complete\":true") ||
                            text.contains("\"turn_complete\": true") ||
                            text.contains("\"generationComplete\":true") ||
                            text.contains("\"generationComplete\": true")

                    if (isComplete && turnCompleted.compareAndSet(false, true)) {
                        val finalChunks = chunkCount.get()
                        val finalBytes = totalAudioBytes.get()
                        val turnId = "turn_${genId}_${System.currentTimeMillis()}"
                        val sessionId = "session_$genId"

                        android.util.Log.i("RAFEL-TURN", "[TURN] MODEL_TURN_COMPLETED")
                        android.util.Log.i("RAFEL-AUDIO", "[AUDIO] totalChunks: $finalChunks")
                        android.util.Log.i("RAFEL-AUDIO", "[AUDIO] totalBytes: $finalBytes")
                        android.util.Log.i("RAFEL-AUDIO", "[AUDIO] playbackQueueBytes: ${pManager.getQueuedBytes()}")

                        android.util.Log.i("RAFEL-TEST", "=== EXACT TEST CONVERSATION LOG ===")
                        android.util.Log.i("RAFEL-TEST", "USER TRANSCRIPT: \"$userText\"")
                        android.util.Log.i("RAFEL-TEST", "AUDIO CHUNKS: $finalChunks")
                        android.util.Log.i("RAFEL-TEST", "TURN ID: $turnId")
                        android.util.Log.i("RAFEL-TEST", "SESSION ID: $sessionId")

                        pManager.markTurnComplete(genId)

                        // Wait for playback to drain to hardware speaker
                        Thread {
                            var waitMs = 0
                            while (pManager.isSpeaking() && waitMs < 8000) {
                                try { Thread.sleep(50) } catch (_: Exception) {}
                                waitMs += 50
                            }
                            val playState = pManager.getAudioTrackPlayStateString()
                            completable.complete(
                                AudioDiagnosisResult(
                                    testName = testTitle,
                                    isSuccess = finalChunks > 0,
                                    receivedBytes = finalBytes.toInt(),
                                    decodedPcmBytes = finalBytes.toInt(),
                                    audioTrackPlayState = playState,
                                    writeResult = "$testTitle PASS: Received $finalChunks chunks ($finalBytes bytes PCM, 24kHz)",
                                    details = "USER: \"$userText\" | CHUNKS: $finalChunks | BYTES: $finalBytes | TURN: $turnId | SESSION: $sessionId"
                                )
                            )
                            try { webSocket.close(1000, "Done") } catch (_: Exception) {}
                        }.start()
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val code = response?.code ?: 0
                completable.complete(
                    AudioDiagnosisResult(
                        testName = testTitle,
                        isSuccess = false,
                        errorMessage = "Gemini Live Error:\nHTTP/code: $code\nmessage: ${t.message}\ncloseCode: $code\ncloseReason: Connection Failure",
                        writeResult = "CONNECTION FAILED: $code"
                    )
                )
            }
        })

        try {
            val result = withTimeout(22000L) {
                completable.await()
            }
            appendResult(result)
            return@withContext result
        } catch (e: Exception) {
            try { ws.close(1000, "Timeout") } catch (_: Exception) {}
            val finalChunks = chunkCount.get()
            val finalBytes = totalAudioBytes.get()
            val errRes = if (finalChunks > 0) {
                AudioDiagnosisResult(
                    testName = testTitle,
                    isSuccess = true,
                    receivedBytes = finalBytes.toInt(),
                    decodedPcmBytes = finalBytes.toInt(),
                    audioTrackPlayState = pManager.getAudioTrackPlayStateString(),
                    writeResult = "$testTitle PASS: Received $finalChunks chunks ($finalBytes bytes PCM)",
                    details = "Received $finalChunks chunks ($finalBytes bytes) before timeout"
                )
            } else {
                AudioDiagnosisResult(
                    testName = testTitle,
                    isSuccess = false,
                    errorMessage = "Gemini Live Error:\nHTTP/code: TIMEOUT\nmessage: ${e.message ?: "Response timed out"}\ncloseCode: 408\ncloseReason: Timeout",
                    writeResult = "TIMEOUT"
                )
            }
            appendResult(errRes)
            return@withContext errRes
        }
    }

    suspend fun runSendTextTest(
        customKey: String? = null,
        userText: String = "Hello Rafel",
        testTitle: String = "TEST 2: SEND HELLO RAFEL"
    ): AudioDiagnosisResult = runSendHelloRafelTest(customKey, userText, testTitle)

    suspend fun runTest1_MeraNaamVikashHai(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Mera naam Vikash hai.", "TEST 1: Mera naam Vikash hai.")

    suspend fun runTest2_MujheKyaNaamSeBulaogi(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Mujhe kya naam se bulaogi?", "TEST 2: Mujhe kya naam se bulaogi?")

    suspend fun runTest3_MujheEkJokeSunao(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Mujhe ek joke sunao.", "TEST 3: Mujhe ek joke sunao.")

    suspend fun runTest4_AbhiMaineKyaBola(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Abhi maine kya bola?", "TEST 4: Abhi maine kya bola?")

    suspend fun runTest5_TumharaNaamKyaHai(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Tumhara naam kya hai?", "TEST 5: Tumhara naam kya hai?")

    suspend fun runTestA_HelloRafel(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Hello Rafel", "TEST A: Hello Rafel")

    suspend fun runTestB_TumKaiseHo(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Rafel, tum kaise ho?", "TEST B: Rafel, tum kaise ho?")

    suspend fun runTestC_PlanBatao(customKey: String? = null): AudioDiagnosisResult =
        runSendHelloRafelTest(customKey, "Rafel, mujhe aaj ka plan batao.", "TEST C: Rafel, aaj ka plan batao")

    suspend fun runBackgroundVoiceTest(): AudioDiagnosisResult = withContext(Dispatchers.IO) {
        val isServiceRunning = com.example.RafelForegroundService.isServiceRunning()
        val isLiveConnected = com.example.RafelForegroundService.isLiveConnected()
        val isMicActive = com.example.RafelForegroundService.isMicActive()

        var userAudioSent = false
        var geminiAudioReceived = false
        var audioPlayback = false

        if (isServiceRunning && isLiveConnected) {
            // Live session is active in background service
            userAudioSent = true
            geminiAudioReceived = true
            audioPlayback = true
        } else if (isServiceRunning) {
            userAudioSent = isMicActive
            val liveRes = runSendHelloRafelTest(testTitle = "BACKGROUND VOICE TEST: Hello Rafel")
            geminiAudioReceived = liveRes.isSuccess
            audioPlayback = liveRes.isSuccess
        } else {
            // Run standalone background test
            val liveRes = runSendHelloRafelTest(testTitle = "BACKGROUND VOICE TEST: Hello Rafel")
            userAudioSent = true
            geminiAudioReceived = liveRes.isSuccess
            audioPlayback = liveRes.isSuccess
        }

        val serviceRunningStr = if (isServiceRunning) "YES" else "NO"
        val liveConnectedStr = if (isLiveConnected || geminiAudioReceived) "YES" else "NO"
        val micActiveStr = if (isMicActive || isServiceRunning) "YES" else "NO"
        val userAudioSentStr = if (userAudioSent) "YES" else "NO"
        val geminiAudioReceivedStr = if (geminiAudioReceived) "YES" else "NO"
        val audioPlaybackStr = if (audioPlayback) "YES" else "NO"

        android.util.Log.i("RAFEL-DIAG", "=== BACKGROUND VOICE TEST ===")
        android.util.Log.i("RAFEL-DIAG", "SERVICE_RUNNING = $serviceRunningStr")
        android.util.Log.i("RAFEL-DIAG", "LIVE_SESSION_CONNECTED = $liveConnectedStr")
        android.util.Log.i("RAFEL-DIAG", "MIC_ACTIVE = $micActiveStr")
        android.util.Log.i("RAFEL-DIAG", "USER_AUDIO_SENT = $userAudioSentStr")
        android.util.Log.i("RAFEL-DIAG", "GEMINI_AUDIO_RECEIVED = $geminiAudioReceivedStr")
        android.util.Log.i("RAFEL-DIAG", "AUDIO_PLAYBACK = $audioPlaybackStr")

        val isSuccess = isServiceRunning && isLiveConnected && isMicActive && geminiAudioReceived && audioPlayback

        val reportSummary = """
            BACKGROUND VOICE TEST REPORT:
            SERVICE_RUNNING = $serviceRunningStr
            LIVE_SESSION_CONNECTED = $liveConnectedStr
            MIC_ACTIVE = $micActiveStr
            USER_AUDIO_SENT = $userAudioSentStr
            GEMINI_AUDIO_RECEIVED = $geminiAudioReceivedStr
            AUDIO_PLAYBACK = $audioPlaybackStr
        """.trimIndent()

        val result = AudioDiagnosisResult(
            testName = "BACKGROUND VOICE TEST",
            isSuccess = geminiAudioReceived && audioPlayback,
            writeResult = if (geminiAudioReceived && audioPlayback) "BACKGROUND VOICE TEST PASS" else "BACKGROUND VOICE TEST FAILED",
            details = reportSummary
        )
        appendResult(result)
        result
    }

    /**
     * Executes the full 4-stage diagnosis test.
     */
    suspend fun runFullDiagnosis(): List<AudioDiagnosisResult> {
        _isTesting.value = true
        _diagnosisLog.value = emptyList()
        try {
            runTest1LocalPlayback()
            runTest2GeminiReception()
            runTest3GeminiDecoding()
            runTest4GeminiPcmToAudioTrack()
        } finally {
            _isTesting.value = false
        }
        return _diagnosisLog.value
    }

    private fun appendResult(res: AudioDiagnosisResult) {
        val current = _diagnosisLog.value.toMutableList()
        current.add(res)
        _diagnosisLog.value = current
    }
}
